#ifndef A429_H
#define A429_H

// D�claration du sous-programme
void afficher_entete_decodeur();
void afficher_mot_a429(unsigned int);
void decoder_mot_a429(unsigned int, int&, int&, double&, int[4]);
void afficher_mot_a429(unsigned int);	

#endif // A429_H
