#ifndef UTILITAIRE_H
#define UTILITAIRE_H
void afficher_heure(unsigned int);
unsigned int decimale_a_octale(unsigned int); 
unsigned int calculer_nb_bits_actifs(unsigned int);
void afficher_bits(unsigned int, int, int);

#endif // UTILITAIRE_H


