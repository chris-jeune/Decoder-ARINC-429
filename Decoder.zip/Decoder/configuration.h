#ifndef _CONFIGURATION_H_
#define _CONFIGURATION_H_


// Requis 1 : Modes d'op�ration
#define TEST
//#define APPLICATION

// Requis 2 : Port UDP pour les donn�es ARINC-429
#define UDP_PORT_NUMBER 55001

// Requis 3 : Parit� des donn�es ARINC-429
#define ODD_PARITY 1  // Parit� impaire

#endif

